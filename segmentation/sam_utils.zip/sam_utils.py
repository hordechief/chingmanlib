from segment_anything import SamPredictor, sam_model_registry
from segment_anything import SamAutomaticMaskGenerator, sam_model_registry,SamPredictor

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import os 
import cv2
import numpy as np

# Choose a model type and a checkpoint
model_type = "vit_h"
checkpoint_path = "/binhe/models/SAM/sam_vit_h_4b8939.pth"

# Create a SAM model and a predictor
sam = sam_model_registry[model_type](checkpoint=checkpoint_path)
predictor = SamPredictor(sam)
        
        
def MyRemoveBackgroundSAM(
        input_path:str,
        output_path:str,
        kernel = ((2,2),2), 
        prompt=(np.array([[100, 100]]),np.array([1])), 
        mask_index=1, 
        transparent_background_color=True, 
        show_result=False):   
    # Load an image
    image = cv2.imread(input_path)
    if image.shape[2] > 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGRA2RGB)
    else:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    # print(image.shape)

    # Set the image for the predictor
    predictor.set_image(image)
    input_point = prompt[0]
    input_label = prompt[1]

    masks, scores, logits = predictor.predict(
        point_coords=input_point,
        point_labels=input_label,
        multimask_output=True,
    )
    # print(masks[2].shape)

    if show_result:
        plt.figure(figsize=(10,10))
        for i, (mask, score) in enumerate(zip(masks, scores)):
            plt.subplot(1,3,i+1)
            plt.imshow(image)
            show_mask(mask, plt.gca())
            show_points(input_point, input_label, plt.gca())
            plt.title(f"Mask {i+1}, Score: {score:.3f}", fontsize=12)
        plt.axis('off')
        plt.show()  

    score = mask_index #np.argmax(scores) #2 # 分数最高的不一定最准确，经验是2，面积最大
    logit = logits[score, :, :] 
    mask = masks[score, :, :]#.astype('uint8')*255
    # print(score,mask)
    if show_result:
        print(scores)

    # Test code
#     height, width, _ = image.shape
#     mask = np.ones((height, width), dtype=np.uint8) * 255
#     center_x, center_y = width // 2, height // 2
#     rect_width, rect_height = width // 2, height // 2
#     cv2.rectangle(mask, (center_x - rect_width // 2, center_y - rect_height // 2), 
#               (center_x + rect_width // 2, center_y + rect_height // 2), 0, thickness=cv2.FILLED)

#     kernel_size = 2
#     iterations = 1
#     kernel = np.ones((kernel_size, kernel_size), np.uint8)  # Change kernel size as needed
#     kernel = np.ones((1, 5), np.uint8)
    kernel_size,iterations = kernel
    kernel = np.ones(kernel_size, np.uint8) 

    _mask = mask*255
    mask_eroded = cv2.erode(_mask.astype('uint8'), kernel, iterations=iterations)

    mask = mask_eroded
    mask_inverse =  cv2.bitwise_not(mask) # 这个地方mask的值必须是乘过255的，否则虽然显示没问题，但not的结果不正确

    content_image = cv2.bitwise_and(image, image, mask=mask)
    if transparent_background_color:
        alpha_channel = np.zeros_like(content_image[:, :, 0])
    else:
        alpha_channel = np.ones_like(content_image[:, :, 0])
    # print(alpha_channel.shape)

    # Merge the content and alpha channel
    object_image_with_alpha = cv2.merge([content_image, alpha_channel]) # 4 channel
    object_image_with_alpha[:, :, 3] = mask
    object_image_with_alpha = cv2.cvtColor(object_image_with_alpha, cv2.COLOR_RGBA2BGRA)
    cv2.imwrite(output_path, object_image_with_alpha)

    if show_result:
        # Display the reuslt
        plt.figure(figsize=(10,10))
        plt.subplot(1,5,1)
        plt.imshow(image)
        plt.title("raw image", fontsize=8)
        plt.subplot(1,5,2)
        plt.title("mask", fontsize=8)
        plt.imshow(mask)
        plt.subplot(1,5,3)
        plt.title("mask eroded", fontsize=8)
        plt.imshow(mask_eroded)
        plt.subplot(1,5,4)
        plt.title("masked content image", fontsize=8)
        plt.imshow(content_image)
        plt.subplot(1,5,5)
        plt.title("final image with alpha", fontsize=8)
        plt.imshow(object_image_with_alpha)
        plt.show()

    return mask,mask_inverse        